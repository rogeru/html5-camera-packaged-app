(function() {

  require(['order!libs/jquery/jquery', 'app'], function($, app) {
    return app.init();
  });

}).call(this);
