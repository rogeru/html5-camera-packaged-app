({
    appDir: "./",
    baseUrl: "./",
    dir: "build",
    optimize: "none"
})