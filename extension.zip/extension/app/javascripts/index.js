(function() {

	window.HTML5CAMERA = {}
	window.HTML5CAMERA.IS_EXTENSION = true;
	jade.render(document.body, 'index', { path: "styles/" });

})();
